import { useState } from 'react';
import './App.css';

function App() {
  let [data, setdata] = useState([]);

  let getdatafrmserver = async () => {
    let jsondata = await fetch("http://localhost:8000/enrolledlist", { method: "GET" }); // ✅ corrected port
    let jsodata = await jsondata.json();
    console.log(jsodata);
    setdata(jsodata);
  };

  return (
    <div className="App">
      <button type="button" onClick={() => getdatafrmserver()}>
        Click me
      </button>

      {data.map((ele, i) => {
        return (
          <div key={i}> {/* ✅ added key */}
            <h1>{ele.name}</h1>
            <h1>{ele.email}</h1>
            <h1>{ele.batchid}</h1> {/* ✅ corrected field */}
          </div>
        );
      })}
    </div>
  );
}

export default App;
