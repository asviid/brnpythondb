from pymongo import MongoClient
from pydantic import BaseModel, Field, EmailStr
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# MongoDB Connection Function
# -----------------------------
def connect_to_db():
    try:
        client = MongoClient(
            "mongodb+srv://akula-vidyullatha:pythonmgdb@asviid.dnbxcei.mongodb.net/?appName=asviid"
        )

        client.admin.command('ping')
        print("Connected to MongoDB successfully!")

        db = client["testdb"]
        collection = db["testcollectiondata"]

        return collection

    except Exception as e:
        print(f"Error connecting to MongoDB: {e}")
        return None


@app.get("/enrolledlist")
def data():
    collection = connect_to_db()  # ✅ fixed undefined variable

    if collection is None:
        return {"status": "error", "message": "Database connection failed"}

    datarevtive = collection.find()
    result = []

    for record in datarevtive:
        record["_id"] = str(record["_id"])  # ✅ convert ObjectId
        result.append(record)

    return result


# -----------------------------
# Pydantic Model
# -----------------------------
class User(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    age: int = Field(..., gt=0)
    email: EmailStr
    password: str
    batchid: str


if __name__ == "__main__":
    connect_to_db()
