
from pymongo import MongoClient  # Import MongoClient to connect to MongoDB
from pydantic import BaseModel,EmailStr, Field  # Import Pydantic tools for data validation


class User(BaseModel):  # Define a Pydantic model named User
    name: str = Field(..., min_length=1, max_length=50)  # Name field (required, 1–50 characters)
    age: int = Field(..., gt=0, lt=90)  # Age field (required, must be between 1 and 89)
    email: EmailStr  # Email field (validated automatically as proper email format)
    password: str  # Password field (string type)


def check_connection():  # Function to check MongoDB connection
    try:  # Try block to handle connection errors
        client = MongoClient("mongodb+srv://akula-vidyullatha:pythonmgdb@asviid.dnbxcei.mongodb.net/?appName=asviid")  
        # Create MongoDB client with connection string

        client.admin.command('ping')  
        # Send a ping command to confirm server connection

        print("Connected and Pinged MongoDB successfully!")  
        # Print success message if connection works

        db = client['testdb']  
        # Access (or create) database named 'testdb'

        collection = db['testcollectiondata']  
        # Access (or create) collection named 'testcollectiondata'

        return collection  
        # Return the collection object

    except Exception as e:  
        # Catch any exception if connection fails

        print(f"Failed to connect to MongoDB: {e}")  
        # Print error message

        return None  
        # Return None if connection fails


def main():  
    # Main function

    print("Hello from validation, insertion, schema!")  
    # Print welcome message

    collection = check_connection()  
    # Call function to check database connection

    if collection is None:  
        # If connection failed

        return  
        # Exit the program

    user_data = User(  
        # Create a User object using Pydantic model

        name="BRN INFOTECH",  
        # Provide name value

        age=20,  
        # Provide age value

        email="brn@gmail.com",  
        # Provide email value

        password="123brnbrn@"  
        # Provide password value
    )

    data = user_data.model_dump()  
    # Convert Pydantic model object into dictionary format
    collection.insert_one(data)

    print(data)  
    # Print dictionary data

    # Insert dictionary into MongoDB collection

    print("Data inserted successfully!")  
    # Print success message after insertion


if __name__ == "__main__":  
    # Check if file is executed directly

    main()  
    # Call main function
