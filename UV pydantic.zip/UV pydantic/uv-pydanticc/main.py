from pydantic import BaseModel
class Users(BaseModel):
    id: int
    name: str
    email: str  

coustmer=Users(id=1, name="John Doe", email="john@example.com")
print(coustmer)


def main():
    print("Hello from uv-pydanticc!")


if __name__ == "__main__":
    main()
