import React from "react";
import "./App.css";

function App() {

  let [data, setData] = React.useState([]);

  let apiBus = async () => {

    let response = await fetch("http://localhost:8000/api/bus", {
      method: "GET",
    });

    let JSOdata = await response.json();
    console.log(JSOdata);

    setData(JSOdata);
  };

  return (
    <div className="App">
      <h2>FastAPI + React</h2>

      <button onClick={apiBus}>
        Fetch Bus Data
      </button>

      {data.map((item, index) => (
        <div key={index}>
          <p>Name: {item.name}</p>
          <p>Age: {item.age}</p>
        </div>
      ))}

    </div>
  );
}

export default App;
