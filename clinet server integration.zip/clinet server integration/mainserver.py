from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow React frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000"],  # React runs on 8000
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/bus")
def api_bus():
    return [{"name": "brn", "age": 22}]
