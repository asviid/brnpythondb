#modules are ntg but .py files 
#modules are three types custom modules (created by me ), inbuilt modules(preprgmmed by someone and i am using it by importing) , external modules (pip modules like nupy pands etcc)
#to import a module we use import keyword
#to import a specific function from a module we use from keyword    
#to import a module we use import keyword



# if i want import module which is in other folder then i have to use dot notation like from foldername import module name    
import addition 
import movie


print(addition.add(2,3)) 
print(addition.add(5,6))
print(addition.multiply(2,3))
print(addition.multiply(5,6))   
movie.abtmovie("Inception","Sci-fi",2010)   
print(movie.abtmovie("Inception","Sci-fi",2010))
