def abtmovie(name,genre,year):
    print(f"{name} is a {genre} movie released in {year}")
    return f"{name} is a {genre} movie released in {year}"