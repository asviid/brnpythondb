import requests
url="https://api.github.com/repos/psf/requests"
response=requests.get(url)
result=response.json()
print(result)
import numpy as np
A=np.array([[1,2],[3,4]])
print(A)
import pandas as pd
data={'Name':['Alice','Bob','Charlie'],'Age':[25,30,35]}
df=pd.DataFrame(data)
print(df)
