import math
print (math.sqrt(16))   
print (math.pow(2,3))
print (math.pi)
print (math.e)
print (math.sin(math.pi/2))
print (math.cos(math.pi/2)) 
print(math.factorial(5))


# Date time  import datetime

 
 # os module
import os
print(os.getcwd())
print(os.listdir())
#system module
import sys
print(sys.version)
print(sys.platform)
#random module
import random
print(random.randint(1,10))
print(random.choice(['apple','banana','cherry']))
print(random.random())
#shil ,re , json , csv ,statics , time , datetime , os , sys , random , math  are some of the inbuilt modules in python which we can use by importing them in our code