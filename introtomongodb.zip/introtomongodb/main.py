from pymongo import MongoClient
def check_connection():
    try:
        client= MongoClient("mongodb+srv://akula-vidyullatha:pythonmgdb@asviid.dnbxcei.mongodb.net/?appName=asviid")
        client.admin.command('ping')
        print("Connection successful    to MongoDB Atlas    cluster established.    ")
    except Exception as e:
        print(f"Error connecting to MongoDB Atlas: {e}")

check_connection()
